#ICE-2
import text_summarizer
import pandas as pd

# Sources
# https://www.bbc.com/news/uk-england-london-62325348 -- Olympic Village
# https://www.bbc.com/news/uk-england-london-62052032 -- Londong 2012
# https://www.bbc.com/news/uk-63162881 -- Met Investigation
# https://www.bbc.com/news/health-63256505 -- Long Covid
# https://www.washingtonpost.com/tv/2023/05/29/succession-finale-review-tom-kendall-logan/ -- Succession Article

first_article = open(r"C:\Users\black\CSCE5222_Feature_Engineering\Feature_Engineering_ICE_2\text-summarizer-master\text-summarizer-master\articles\london_2012.txt")
second_article = open(r"C:\Users\black\CSCE5222_Feature_Engineering\Feature_Engineering_ICE_2\text-summarizer-master\text-summarizer-master\articles\long_covid.txt")
third_article = open(r"C:\Users\black\CSCE5222_Feature_Engineering\Feature_Engineering_ICE_2\text-summarizer-master\text-summarizer-master\articles\met_bbc.txt")
fourth_article = open(r"C:\Users\black\CSCE5222_Feature_Engineering\Feature_Engineering_ICE_2\text-summarizer-master\text-summarizer-master\articles\olympic_village.txt")
fifth_article = open(r"C:\Users\black\CSCE5222_Feature_Engineering\Feature_Engineering_ICE_2\text-summarizer-master\text-summarizer-master\articles\succession_article.txt")

content_one = first_article.read()
content_two = second_article.read()
content_three = third_article.read()
content_four =  fourth_article.read()
content_five = fifth_article.read()

# print(content_one) #check

df_one = pd.DataFrame()
df_two = pd.DataFrame()
df_three = pd.DataFrame()
df_four = pd.DataFrame()
df_five = pd.DataFrame()

df_one["File_Name"] = "London_2012"
df_one['Content'] = content_one
df_one['Changed_Content'] = content_one

df_two["File_Name"] = "Long_Covid"
df_two['Content'] = content_two
df_two['Changed_Content'] = content_two

df_three["File_Name"] = "Met_BBC"
df_three['Content'] = content_three
df_three['Changed_Content'] = content_three

df_four["File_Name"] = "Olympic_Village"
df_four['Content'] = content_four
df_four['Changed_Content'] = content_four

df_five["File_Name"] = "Succession_Article"
df_five['Content'] = content_five
df_five['Changed_Content'] = content_five

#perform text cleaning
#1.1 Special Character Cleaning
df_one['Changed_Content'] = df_one['Changed_Content'].str.replace("\r"," ")
df_one['Changed_Content'] = df_one['Changed_Content'].str.replace("\n"," ")
df_one['Changed_Content'] = df_one['Changed_Content'].str.replace("    ", " ")

#1.2 Uppercase and Lowercase
df_one['Changed_Content'] = df_one['Changed_Content'].str.lower()

#1.3 Punctuation signs
punctuation_signs=list("?!:.,:-")

for p in punctuation_signs:
    df_one['Changed_Content'] = df_one['Changed_Content'].str.replace(p, '')

#1.4 Possessive Pronouns
df_one['Changed_Content'] = df_one['Changed_Content'].str.replace("'s", "")

#1.5 Stemming and Lemmatization
import nltk
nltk.download('punkt')
nltk.download('wordnet')

wordnet_lemmatizer = WordNetLemmatizer()

nrows = len(df_one)
lemmatized_text_list = []

for row in range(0, nrows):
    
    # Create an empty list containing lemmatized words
    lemmatized_list = []
    
    # Save the text and its words into an object
    text = df_one.loc[row]['Changed_Content']
    text_words = text.split(" ")

    # Iterate through every word to lemmatize
    for word in text_words:
        lemmatized_list.append(wordnet_lemmatizer.lemmatize(word, pos="v"))
        
    # Join the list
    lemmatized_text = " ".join(lemmatized_list)
    
    # Append to the list containing the texts
    lemmatized_text_list.append(lemmatized_text)
    
df_text['Changed_Content'] = lemmatized_text_list

#1.6 Stop Words

nltk.download('stopwords')

# Loading the stop words in english
stop_words = list(stopwords.words('english'))

df_text['Changed_Content'] = df_text['Changed_Content']

for stop_word in stop_words:

    regex_stopword = r"\b" + stop_word + r"\b"
    df_text['Changed_Content'] = df_text['Changed_Content'].str.replace(regex_stopword, '')

#text_summarizer.generate_summary(first_article,2)
#print("break")
#text_summarizer.generate_summary(second_article,2)
#print("break")
#text_summarizer.generate_summary(third_article,2)
#print("break")
#text_summarizer.generate_summary(fourth_article,2)
#print("break")
#text_summarizer.generate_summary(fifth_article,2)

